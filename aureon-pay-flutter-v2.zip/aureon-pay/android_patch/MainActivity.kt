package com.pavan.aureon_budget

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var pending: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "aureon/upi").setMethodCallHandler { call, result ->
            when (call.method) {
                "apps" -> {
                    val probe = Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay?pa=test@upi&pn=t&am=1&cu=INR"))
                    val list = packageManager.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY).map {
                        mapOf("pkg" to it.activityInfo.packageName, "name" to it.loadLabel(packageManager).toString())
                    }
                    result.success(list)
                }
                "pay" -> {
                    if (pending != null) {
                        result.error("busy", "Payment already running", null)
                    } else {
                        val i = Intent(Intent.ACTION_VIEW, Uri.parse(call.argument<String>("uri")))
                        i.setPackage(call.argument<String>("pkg"))
                        pending = result
                        try {
                            startActivityForResult(i, 9001)
                        } catch (e: Exception) {
                            pending = null
                            result.error("fail", e.message, null)
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9001) {
            val r = pending
            pending = null
            r?.success(data?.getStringExtra("response") ?: "")
        }
    }
}
