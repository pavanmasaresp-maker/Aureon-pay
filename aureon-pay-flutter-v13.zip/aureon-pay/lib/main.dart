import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';

void main() => runApp(const App());

const kP = Color(0xFF8B5CF6), kC = Color(0xFF38D9F5), kBg = Color(0xFF07080F), kCard = Color(0xFF11131F);

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Aureon Budget',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
            scaffoldBackgroundColor: kBg,
            colorScheme: const ColorScheme.dark(primary: kP, secondary: kC, surface: kCard)),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  Map<String, dynamic>? d; // {sal, c:{name:{t,s}}, h:[{k,a,n}]}
  SharedPreferences? sp;
  static const ch = MethodChannel('aureon/upi');
  int tab = 0;
  bool lis = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.resumed) {
      _drain();
      _checkLink();
    }
  }

  Future<void> _load() async {
    sp = await SharedPreferences.getInstance();
    final r = sp!.getString('budget');
    setState(() => d = r == null ? null : jsonDecode(r));
    if (d == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _setup());
    } else {
      _drain();
      _checkLink();
    }
  }

  void _recalc() {
    final c = d!['c'] as Map;
    c.forEach((k, v) => v['s'] = 0.0);
    for (final h in (d!['h'] as List)) {
      if (h['in'] == true) continue;
      final m = c[h['k']];
      if (m != null) m['s'] = (m['s'] as num) + (h['a'] as num);
    }
  }

  void _save() {
    if (d != null) _recalc();
    sp?.setString('budget', jsonEncode(d));
    setState(() {});
  }

  String inr(num n) => '₹${n.round()}';
  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Widget _tf(TextEditingController c, String l, {TextInputType? k}) => Padding(
      padding: const EdgeInsets.only(top: 8),
      child: TextField(
          controller: c,
          keyboardType: k ?? TextInputType.number,
          decoration: InputDecoration(labelText: l, border: const OutlineInputBorder())));

  Future<bool> _confirm(String m) async =>
      await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(content: Text(m), actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Nahi')),
                TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Haan')),
              ])) ??
      false;

  Future<void> _setup() async {
    final names = ['Fast food', 'Savings', 'Emergency fund', 'Daily expenses'];
    final sal = TextEditingController();
    final cs = names.map((_) => TextEditingController()).toList();
    await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
              title: const Text('Budget set karo'),
              content: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                _tf(sal, 'Monthly salary'),
                for (var i = 0; i < names.length; i++) _tf(cs[i], names[i]),
              ])),
              actions: [
                TextButton(
                    onPressed: () {
                      final s = double.tryParse(sal.text);
                      if (s == null) return;
                      d = {
                        'sal': s,
                        'c': {
                          for (var i = 0; i < names.length; i++)
                            names[i]: {'t': double.tryParse(cs[i].text) ?? 0.0, 's': 0.0}
                        },
                        'h': []
                      };
                      _save();
                      Navigator.pop(ctx);
                    },
                    child: const Text('Shuru karo'))
              ],
            ));
  }

  Future<void> _add() async {
    final n = TextEditingController(), a = TextEditingController();
    await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('Naya category'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                _tf(n, 'Naam', k: TextInputType.text),
                _tf(a, 'Amount'),
              ]),
              actions: [
                TextButton(
                    onPressed: () {
                      final k = n.text.trim();
                      if (k.isEmpty || (d!['c'] as Map).containsKey(k)) return;
                      d!['c'][k] = {'t': double.tryParse(a.text) ?? 0.0, 's': 0.0};
                      _save();
                      Navigator.pop(ctx);
                    },
                    child: const Text('Add'))
              ],
            ));
  }

  Future<void> _edit(String k) async {
    final c = TextEditingController(text: '${d!['c'][k]['t']}');
    await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(title: Text(k), content: _tf(c, 'Amount'), actions: [
              TextButton(
                  onPressed: () async {
                    Navigator.pop(ctx);
                    if (await _confirm('$k delete karna hai?')) {
                      (d!['c'] as Map).remove(k);
                      _save();
                    }
                  },
                  child: const Text('Delete', style: TextStyle(color: Colors.redAccent))),
              TextButton(
                  onPressed: () {
                    d!['c'][k]['t'] = double.tryParse(c.text) ?? 0.0;
                    _save();
                    Navigator.pop(ctx);
                  },
                  child: const Text('Save')),
            ]));
  }

  void _spend(String cat, double a, String note, String pn) {
    final m = d!['c'][cat];
    if (m == null) return;
    m['s'] = (m['s'] as num) + a;
    (d!['h'] as List).add({'k': cat, 'a': a, 'n': note.isNotEmpty ? note : pn, 't': DateTime.now().millisecondsSinceEpoch});
    _save();
  }

  Future<void> _pay(String? k, {bool scan = false, Map<String, String>? pre}) async {
    final cats = (d!['c'] as Map).keys.cast<String>().toList();
    if (cats.isEmpty) {
      _snack('Pehle category add karo');
      return;
    }
    String cat = k ?? cats.first;
    bool auto = scan;
    final amt = TextEditingController(), note = TextEditingController();
    final paC = TextEditingController(), pnC = TextEditingController();
    if (pre != null) {
      paC.text = pre['pa'] ?? '';
      pnC.text = pre['pn'] ?? '';
      amt.text = pre['am'] ?? '';
      note.text = pre['pn'] ?? '';
    }
    List<Map<String, String>> apps = [];
    try {
      final r = await ch.invokeMethod<List<dynamic>>('apps');
      apps = (r ?? []).map((e) => Map<String, String>.from(e as Map)).toList();
    } catch (_) {}
    if (!mounted) return;
    await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: kCard,
        showDragHandle: true,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (ctx) => StatefulBuilder(builder: (ctx, set) {
              Future<void> doScan([String m = 'scan']) async {
                String? r;
                try {
                  r = await ch.invokeMethod<String>(m);
                } catch (e) {
                  _snack('Scanner chalu nahi hua: $e');
                  return;
                }
                if (r == null) return;
                if (r.isEmpty) {
                  _snack('QR padha nahi gaya. Saaf aur seedha screenshot lo');
                  return;
                }
                if (!r.startsWith('upi://')) {
                  _snack('Ye UPI QR nahi hai');
                  return;
                }
                final q = Uri.parse(r).queryParameters;
                set(() {
                  paC.text = q['pa'] ?? '';
                  pnC.text = q['pn'] ?? '';
                  if (q['am'] != null) amt.text = q['am']!;
                  if (note.text.isEmpty) note.text = pnC.text;
                });
              }

              if (auto) {
                auto = false;
                WidgetsBinding.instance.addPostFrameCallback((_) => doScan());
              }

              void go(Map<String, String> app) {
                final a = double.tryParse(amt.text);
                if (a == null || a <= 0 || paC.text.trim().isEmpty) {
                  _snack('Amount aur UPI ID (ya QR scan) zaroori hai');
                  return;
                }
                Navigator.pop(ctx);
                _run(app, cat, a, note.text, paC.text.trim(), pnC.text.trim());
              }

              final cur = d!['c'][cat];
              return Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
                child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Payment', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                      value: cat,
                      items: cats.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (v) => set(() => cat = v!)),
                  if (cur != null)
                    Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text('Bacha hai: ${inr((cur['t'] as num) - (cur['s'] as num))}',
                            style: const TextStyle(color: Colors.white60))),
                  _tf(amt, 'Amount (₹)', k: const TextInputType.numberWithOptions(decimal: true)),
                  _tf(note, 'Kis liye? (optional)', k: TextInputType.text),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                      onPressed: doScan, icon: const Icon(Icons.qr_code_scanner), label: const Text('Shop ka QR scan karo')),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(onPressed: () => doScan('scanImage'), icon: const Icon(Icons.image_outlined), label: const Text('Gallery / screenshot se QR')),
                  _tf(paC, 'Receiver UPI ID', k: TextInputType.emailAddress),
                  _tf(pnC, 'Receiver ka naam', k: TextInputType.text),
                  const SizedBox(height: 14),
                  const Text('UPI app chuno', style: TextStyle(color: Colors.white60)),
                  const SizedBox(height: 8),
                  if (apps.isEmpty) const Text('Koi UPI app nahi mila'),
                  Wrap(spacing: 14, runSpacing: 10, children: [
                    for (final a in apps)
                      InkWell(
                          onTap: () => go(a),
                          child: SizedBox(
                              width: 72,
                              child: Column(children: [
                                CircleAvatar(radius: 22, backgroundColor: const Color(0xFF4C2BC4), child: Text(a['name']![0].toUpperCase())),
                                Text(a['name']!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
                              ])))
                  ]),
                  const SizedBox(height: 10),
                  TextButton(
                      onPressed: () {
                        final a = double.tryParse(amt.text);
                        if (a == null || a <= 0) return;
                        Navigator.pop(ctx);
                        _spend(cat, a, note.text, pnC.text);
                      },
                      child: const Text('Cash / bina app ke add karo')),
                ])),
              );
            }));
  }

  Future<void> _run(Map<String, String> app, String cat, double a, String note, String pa, String pn) async {
    final uri = 'upi://pay?pa=${Uri.encodeComponent(pa)}&pn=${Uri.encodeComponent(pn.isEmpty ? pa : pn)}&am=${a.toStringAsFixed(2)}&cu=INR&tn=${Uri.encodeComponent(note.isEmpty ? 'Aureon' : note)}&tr=AUR${DateTime.now().millisecondsSinceEpoch}';
    d!['lp'] = {'a': a, 't': DateTime.now().millisecondsSinceEpoch};
    sp?.setString('budget', jsonEncode(d));
    String st = '';
    try {
      final r = await ch.invokeMethod<String>('pay', {'pkg': app['pkg'], 'uri': uri});
      final m = RegExp(r'status=([A-Za-z]+)', caseSensitive: false).firstMatch(r ?? '');
      if (m != null) st = m.group(1)!.toLowerCase();
    } catch (_) {}
    if (!mounted) return;
    if (st == 'success') {
      _spend(cat, a, note, pn);
      _snack('Payment success. $cat se ${inr(a)} minus ho gaya');
    } else if (st == 'failure' || st == 'failed') {
      d!.remove('lp');
      _snack('Payment fail hui. Kuch minus nahi hua');
    } else if (await _confirm('Status confirm nahi hua. Payment ho gaya?')) {
      _spend(cat, a, note, pn);
    }
  }

  Future<void> _checkLink() async {
    if (d == null) return;
    String? l;
    try {
      l = await ch.invokeMethod<String>('link');
    } catch (_) {}
    if (l == null || !l.startsWith('upi://')) return;
    final q = Uri.parse(l).queryParameters;
    if (q['pa'] == null) return;
    _pay(null, pre: {'pa': q['pa']!, 'pn': q['pn'] ?? '', 'am': q['am'] ?? ''});
  }

  Map<String, dynamic>? _parse(Map e) {
    final txt = '${e['title']} ${e['text']}';
    final m = RegExp(r'(?:₹|rs\.?|inr)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)', caseSensitive: false).firstMatch(txt) ??
        RegExp(r'(?:debited|credited)\s+(?:by|with|for|of)?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)', caseSensitive: false).firstMatch(txt);
    if (m == null) return null;
    final a = double.tryParse(m.group(1)!.replaceAll(',', ''));
    if (a == null || a <= 0) return null;
    final low = txt.toLowerCase();
    final inn = RegExp(r'received|credited|paid you|sent you|deposited').hasMatch(low);
    final out = RegExp(r'debited|paid ₹|paid rs|paid to|payment of|payment to|sent to|you paid|you sent|transferred to').hasMatch(low);
    if (inn == out) return null;
    final n = RegExp(r'\b(?:to|from)\s+([A-Za-z][A-Za-z0-9 .&_-]{1,30}?)(?=\s+(?:Refno|Ref|UPI|on|via|A/c|Txn|If|Not|Avl)\b|[.,;(]|$)', caseSensitive: false).firstMatch(txt);
    final rf = RegExp(r'(?:ref(?:\s*no)?|utr)\.?\s*(?:no\.?|number)?\s*:?\s*([0-9]{6,})', caseSensitive: false).firstMatch(txt);
    return {'a': a, 'n': n?.group(1)?.trim() ?? '', 'in': inn, 'ref': rf?.group(1)};
  }

  Future<void> _drain() async {
    if (d == null) return;
    try {
      final on = (await ch.invokeMethod<bool>('enabled') ?? false) || (await ch.invokeMethod<bool>('smsGranted') ?? false);
      final raw = await ch.invokeMethod<String>('drain') ?? '[]';
      final list = jsonDecode(raw) as List;
      final seen = ((d!['seen'] as List?) ?? []).cast<String>().toList();
      d!['p'] = (d!['p'] as List?) ?? [];
      for (final e in list) {
        if ('${e['pkg']}' == 'acch') {
          final its = _parseHist('${e['text']}');
          _log('PhonePe history: ${its.length} item', e);
          _mergeSync(its);
          continue;
        }
        final key = '${e['pkg']}' == 'acc' ? 'acc|${e['text']}' : '${e['pkg']}|${e['t']}|${e['text']}';
        if (seen.contains(key)) continue;
        seen.add(key);
        final t = _parse(e as Map);
        if (t == null) {
          _log('parse nahi hua', e);
          continue;
        }
        final tt = (e['t'] as num).toInt();
        final pk = '${e['pkg']}';
        final src = pk == 'sms' ? 'sms' : (pk == 'acc' ? 'acc' : 'notif');
        final ref = t['ref'];
        final recL = ((d!['rec'] as List?) ?? []).toList();
        final dup = recL.any((r) =>
            (r['a'] as num) == t['a'] &&
            r['i'] == t['in'] &&
            ((ref != null && r['ref'] == ref) || (r['s'] != src && ((r['t'] as num) - tt).abs() < 120000)));
        if (dup) {
          _log('duplicate (skip)', e);
          continue;
        }
        _log('ok', e);
        recL.add({'a': t['a'], 'i': t['in'], 't': tt, 'ref': ref, 's': src});
        d!['rec'] = recL.length > 30 ? recL.sublist(recL.length - 30) : recL;
        if (t['in'] == true) {
          (d!['h'] as List).add({'k': 'Received', 'a': t['a'], 'n': t['n'], 'in': true, 't': tt});
        } else {
          final lp = d!['lp'] as Map?;
          final now = DateTime.now().millisecondsSinceEpoch;
          if (lp != null && (lp['a'] as num) == t['a'] && now - (lp['t'] as num) < 300000) {
            d!.remove('lp');
            continue;
          }
          final cats = (d!['c'] as Map).keys.cast<String>().toList();
          if (d!['auto'] != false && cats.isNotEmpty) {
            final cat = _guess('${t['n']} ${e['text']}', cats);
            final a = (t['a'] as num).toDouble();
            d!['c'][cat]['s'] = (d!['c'][cat]['s'] as num) + a;
            (d!['h'] as List).add({'k': cat, 'a': a, 'n': t['n'], 'auto': true, 't': tt});
          } else {
            (d!['p'] as List).add({'a': t['a'], 'n': t['n']});
          }
        }
      }
      d!['seen'] = seen.length > 200 ? seen.sublist(seen.length - 200) : seen;
      _recalc();
      sp?.setString('budget', jsonEncode(d));
      setState(() => lis = on);
    } catch (_) {}
  }

  void _dropPend(dynamic p) {
    (d!['p'] as List).remove(p);
    _save();
  }

  Future<void> _enableDetect() async {
    await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('Auto detect on karo'),
              content: const Text('Notification band ho tab bhi bank SMS se kaam karta hai.\n\n1) "App info" dabao, upar teen dots me "Allow restricted settings" dabao.\n2) "SMS allow" dabao aur permission do.\n\nYa "Notif access" me Aureon ko ON karo.\n\nScreen detect (beta): SMS na aaye tab bhi PhonePe / GPay / Paytm ka payment-success screen padhta hai.\n\nSirf paisa wale SMS, notifications aur payment screens padhe jate hain, data phone me hi rehta hai.'),
              actions: [
                TextButton(onPressed: () => ch.invokeMethod('appInfo'), child: const Text('App info')),
                TextButton(onPressed: () => ch.invokeMethod('smsRequest'), child: const Text('SMS allow')),
                TextButton(onPressed: () => ch.invokeMethod('accSettings'), child: const Text('Screen detect')),
                TextButton(onPressed: () => ch.invokeMethod('listenerSettings'), child: const Text('Notif access')),
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Band')),
              ],
            ));
    _drain();
  }

  List<Widget> _alerts() {
    final pend = (d!['p'] as List?) ?? [];
    final cats = (d!['c'] as Map).keys.cast<String>().toList();
    return [
      if (!lis)
        Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _card(ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.notifications_active_rounded, color: kC),
                title: const Text('Auto detect on karo'),
                subtitle: const Text('Kisi bhi UPI app ka paid / received yahan dikhega', style: TextStyle(fontSize: 12, color: Colors.white54)),
                trailing: const Icon(Icons.chevron_right),
                onTap: _enableDetect))),
      if (_unknownSync() > 0)
        Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _card(ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.sync_rounded, color: kC),
                title: Text('PhonePe History se ${_unknownSync()} naye payment mile'),
                subtitle: const Text('Review karke add karo', style: TextStyle(fontSize: 12, color: Colors.white54)),
                trailing: const Icon(Icons.chevron_right),
                onTap: _reviewSync))),
      for (final p in pend)
        Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _card(Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Paid ${inr(p['a'] as num)}${(p['n'] as String).isEmpty ? '' : ' · ${p['n']}'}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const Text('Kis category se minus karu?', style: TextStyle(fontSize: 12, color: Colors.white54)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    for (final k in cats)
                      ActionChip(
                          label: Text(k),
                          onPressed: () {
                            _spend(k, (p['a'] as num).toDouble(), p['n'] as String, '');
                            _dropPend(p);
                          }),
                    ActionChip(label: const Text('Ignore'), onPressed: () => _dropPend(p)),
                  ]),
                ])))),
    ];
  }

  void _log(String w, dynamic e) {
    final l = ((d!['log'] as List?) ?? []).toList();
    final x = '${e['title']} ${e['text']}'.replaceAll('\n', ' ');
    l.add({'w': w, 'x': x.length > 170 ? x.substring(0, 170) : x});
    d!['log'] = l.length > 25 ? l.sublist(l.length - 25) : l;
  }

  Future<void> _showLog() async {
    final l = ((d!['log'] as List?) ?? []).reversed.toList();
    await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('Detection log'),
              content: SizedBox(
                  width: double.maxFinite,
                  child: ListView(shrinkWrap: true, children: [
                    if (l.isEmpty) const Text('Abhi koi paisa wala SMS / notification nahi aaya'),
                    for (final x in l)
                      Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('${x['w']}', style: const TextStyle(fontSize: 11, color: kC)),
                            Text('${x['x']}', style: const TextStyle(fontSize: 12, color: Colors.white70)),
                          ])),
                  ])),
              actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Band'))],
            ));
  }

  Future<void> _showArchive() async {
    await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: kCard,
        showDragHandle: true,
        builder: (ctx) => StatefulBuilder(builder: (ctx, set) {
              final arch = ((d!['arch'] as List?) ?? []).reversed.toList();
              return SafeArea(
                  child: ConstrainedBox(
                      constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
                      child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
                        const Text('Archive', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                        if (arch.isEmpty) const Padding(padding: EdgeInsets.all(14), child: Text('Archive khali hai', style: TextStyle(color: Colors.white54))),
                        for (final h in arch)
                          ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(('${h['n']}').isEmpty ? '${h['k']}' : '${h['n']}'),
                              subtitle: Text('${h['k']} · −${inr(h['a'] as num)}', style: const TextStyle(fontSize: 12, color: Colors.white54)),
                              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(
                                    icon: const Icon(Icons.restore_rounded, color: kC),
                                    onPressed: () {
                                      (d!['arch'] as List).remove(h);
                                      h.remove('dt');
                                      (d!['h'] as List).add(h);
                                      _save();
                                      set(() {});
                                    }),
                                IconButton(
                                    icon: const Icon(Icons.delete_forever_rounded, color: Colors.redAccent),
                                    onPressed: () async {
                                      if (await _confirm('Hamesha ke liye delete karna hai?')) {
                                        (d!['arch'] as List).remove(h);
                                        _save();
                                        set(() {});
                                      }
                                    }),
                              ])),
                      ])));
            }));
  }

  Future<void> _cash() async {
    final cats = (d!['c'] as Map).keys.cast<String>().toList();
    if (cats.isEmpty) {
      _snack('Pehle category add karo');
      return;
    }
    String cat = cats.first;
    final amt = TextEditingController(), note = TextEditingController();
    await showDialog(
        context: context,
        builder: (ctx) => StatefulBuilder(
            builder: (ctx, set) => AlertDialog(
                  title: const Text('Cash / offline payment'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    DropdownButtonFormField<String>(
                        value: cat,
                        items: cats.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                        onChanged: (v) => set(() => cat = v!)),
                    _tf(amt, 'Amount (₹)', k: const TextInputType.numberWithOptions(decimal: true)),
                    _tf(note, 'Kis liye? (optional)', k: TextInputType.text),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                    TextButton(
                        onPressed: () {
                          final a = double.tryParse(amt.text);
                          if (a == null || a <= 0) return;
                          _spend(cat, a, note.text, 'Cash');
                          (d!['h'] as List).last['cash'] = true;
                          _save();
                          Navigator.pop(ctx);
                        },
                        child: const Text('Add')),
                  ],
                )));
  }

  List<Map<String, dynamic>> _parseHist(String txt) {
    final lines = txt.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final idx = <int>[];
    for (var j = 0; j < lines.length; j++) {
      final l = lines[j].toLowerCase();
      if (l == 'paid to' || l == 'received from') idx.add(j);
    }
    final out = <Map<String, dynamic>>[];
    for (var k = 0; k < idx.length; k++) {
      final end = k + 1 < idx.length ? idx[k + 1] : lines.length;
      final seg = lines.sublist(idx[k], end);
      final inn = seg[0].toLowerCase() == 'received from';
      final name = seg.length > 1 ? seg[1] : '';
      double? a;
      var when = '';
      for (final l in seg.skip(2)) {
        final m = RegExp(r'₹\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)').firstMatch(l);
        if (m != null && a == null) a = double.tryParse(m.group(1)!.replaceAll(',', ''));
        if (RegExp(r'ago$|^yesterday$|^today$|^\d{1,2}\s+[A-Za-z]{3}', caseSensitive: false).hasMatch(l)) when = l;
      }
      if (a != null && name.isNotEmpty) out.add({'n': name, 'a': a, 'in': inn, 'w': when});
    }
    return out;
  }

  void _mergeSync(List<Map<String, dynamic>> items) {
    final cur = ((d!['sync'] as List?) ?? []).toList();
    for (final it in items) {
      final k = '${it['n']}|${it['a']}|${it['in']}|${it['w']}';
      if (cur.any((x) => '${x['n']}|${x['a']}|${x['in']}|${x['w']}' == k)) continue;
      it['ts'] = DateTime.now().millisecondsSinceEpoch;
      cur.add(it);
    }
    d!['sync'] = cur.length > 200 ? cur.sublist(cur.length - 200) : cur;
  }

  String _nz(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  int? _agoMs(dynamic it) {
    final m = RegExp(r'(\d+)\s*(minute|min|hour|hr|day)s?\s*ago', caseSensitive: false).firstMatch('${it['w']}');
    if (m == null) return null;
    final v = int.parse(m.group(1)!);
    final u = m.group(2)!.toLowerCase();
    final unit = u.startsWith('min') ? 60000 : (u.startsWith('h') ? 3600000 : 86400000);
    return v * unit;
  }

  bool _known(dynamic it) {
    final all = [...(d!['h'] as List), ...((d!['arch'] as List?) ?? [])];
    final n = _nz('${it['n']}');
    final ago = _agoMs(it);
    final when = ago == null ? null : (it['ts'] as num).toInt() - ago;
    for (final h in all) {
      if (((h['a'] as num) - (it['a'] as num)).abs() > 0.01) continue;
      if ((h['in'] == true) != (it['in'] == true)) continue;
      final hn = _nz('${h['n']}');
      if (!(hn.isEmpty || n.isEmpty || n.startsWith(hn) || hn.startsWith(n))) continue;
      final ht = h['t'];
      if (when != null && ht is num && (ht - when).abs() > 4 * 3600 * 1000) continue;
      return true;
    }
    return false;
  }

  int _unknownSync() => ((d!['sync'] as List?) ?? []).where((x) => !_known(x)).length;

  void _importSync(List items, Set<int> sel) {
    final cats = (d!['c'] as Map).keys.cast<String>().toList();
    for (final i in sel) {
      final it = items[i];
      final ago = _agoMs(it);
      final base = (it['ts'] as num).toInt();
      final t = ago == null ? base : base - ago;
      if (it['in'] == true) {
        (d!['h'] as List).add({'k': 'Received', 'a': it['a'], 'n': it['n'], 'in': true, 't': t});
      } else if (cats.isNotEmpty) {
        (d!['h'] as List).add({'k': _guess('${it['n']}', cats), 'a': it['a'], 'n': it['n'], 'auto': true, 't': t});
      }
    }
    final c = sel.length;
    d!['sync'] = [];
    _save();
    _snack('$c entry add ho gayi');
  }

  Future<void> _reviewSync() async {
    final items = ((d!['sync'] as List?) ?? []).toList();
    if (items.isEmpty) {
      _snack('Pehle PhonePe me History kholo aur scroll karo, phir yahan aao');
      return;
    }
    final sel = <int>{
      for (var i = 0; i < items.length; i++)
        if (!_known(items[i])) i
    };
    await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: kCard,
        showDragHandle: true,
        builder: (ctx) => StatefulBuilder(
            builder: (ctx, set) => SafeArea(
                child: ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.8),
                    child: Column(children: [
                      const Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 8), child: Align(alignment: Alignment.centerLeft, child: Text('PhonePe History', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)))),
                      Expanded(
                          child: ListView(children: [
                        for (var i = 0; i < items.length; i++)
                          CheckboxListTile(
                              value: sel.contains(i),
                              onChanged: (v) => set(() {
                                    if (v == true) {
                                      sel.add(i);
                                    } else {
                                      sel.remove(i);
                                    }
                                  }),
                              title: Text('${items[i]['n']}'),
                              subtitle: Text('${items[i]['in'] == true ? 'Received' : 'Paid'} · ${items[i]['w']}${_known(items[i]) ? ' · shayad pehle se hai' : ''}', style: const TextStyle(fontSize: 12, color: Colors.white54)),
                              secondary: Text('${items[i]['in'] == true ? '+' : '−'}${inr(items[i]['a'] as num)}', style: TextStyle(fontWeight: FontWeight.w700, color: items[i]['in'] == true ? const Color(0xFF3DDC97) : const Color(0xFFFF6B81)))),
                      ])),
                      Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(children: [
                            Expanded(
                                child: OutlinedButton(
                                    onPressed: () {
                                      d!['sync'] = [];
                                      _save();
                                      Navigator.pop(ctx);
                                    },
                                    child: const Text('Clear'))),
                            const SizedBox(width: 12),
                            Expanded(
                                child: ElevatedButton(
                                    onPressed: () {
                                      _importSync(items, sel);
                                      Navigator.pop(ctx);
                                    },
                                    child: Text('Add (${sel.length})'))),
                          ])),
                    ])))));
  }

  String _guess(String txt, List<String> cats) {
    final low = txt.toLowerCase();
    if (cats.contains('Fast food') && RegExp(r'\b(?:swiggy|zomato|domino\w*|pizza\w*|mcdonald\w*|kfc|burger\w*|cafe|restaurant\w*|biryani|bakery|chai|eatsure|subway)\b').hasMatch(low)) return 'Fast food';
    final def = d!['def'];
    if (def is String && cats.contains(def)) return def;
    return cats.contains('Daily expenses') ? 'Daily expenses' : cats.first;
  }

  Future<void> _move(dynamic h) async {
    final cats = (d!['c'] as Map).keys.cast<String>().toList();
    final pick = await showDialog<String>(
        context: context,
        builder: (ctx) => SimpleDialog(title: const Text('Category badlo'), children: [
              for (final k in cats) SimpleDialogOption(onPressed: () => Navigator.pop(ctx, k), child: Text(k)),
              SimpleDialogOption(onPressed: () => Navigator.pop(ctx, '__del'), child: const Text('Archive me bhejo (paisa wapas)', style: TextStyle(color: Colors.redAccent))),
            ]));
    if (pick == null) return;
    final a = (h['a'] as num).toDouble();
    final old = d!['c'][h['k']];
    if (old != null) old['s'] = (old['s'] as num) - a;
    if (pick == '__del') {
      (d!['h'] as List).remove(h);
      final arch = ((d!['arch'] as List?) ?? []).toList();
      h['dt'] = DateTime.now().millisecondsSinceEpoch;
      arch.add(h);
      d!['arch'] = arch;
    } else {
      d!['c'][pick]['s'] = (d!['c'][pick]['s'] as num) + a;
      h['k'] = pick;
    }
    _save();
  }

  IconData _ico(String k) {
    switch (k) {
      case 'Fast food':
        return Icons.fastfood_rounded;
      case 'Savings':
        return Icons.savings_rounded;
      case 'Emergency fund':
        return Icons.health_and_safety_rounded;
      case 'Daily expenses':
        return Icons.shopping_cart_rounded;
      default:
        return Icons.category_rounded;
    }
  }

  Future<void> _reset() async {
    if (await _confirm('Sab reset karna hai?')) {
      await sp?.remove('budget');
      setState(() {
        d = null;
        tab = 0;
      });
      _setup();
    }
  }

  Future<void> _editSal() async {
    final c = TextEditingController(text: '${d!['sal']}');
    await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(title: const Text('Monthly salary'), content: _tf(c, 'Salary (₹)'), actions: [
              TextButton(
                  onPressed: () {
                    d!['sal'] = double.tryParse(c.text) ?? 0.0;
                    _save();
                    Navigator.pop(ctx);
                  },
                  child: const Text('Save'))
            ]));
  }

  Widget _card(Widget child, {EdgeInsets? pad}) => Container(
      padding: pad ?? const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF242842))),
      child: child);

  Widget _h(String t, [String? sub]) => Padding(
      padding: const EdgeInsets.fromLTRB(2, 22, 2, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        if (sub != null) Text(sub, style: const TextStyle(fontSize: 12, color: Colors.white54)),
      ]));

  Widget _top() => Row(children: [
        Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [kP, kC]), boxShadow: [BoxShadow(color: Color(0x558B5CF6), blurRadius: 14)]),
            child: const Icon(Icons.auto_awesome, size: 20)),
        const SizedBox(width: 10),
        const Text('AUREON', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 4, fontSize: 15)),
        const Spacer(),
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF242842))),
            child: const Text('Budget & Pay', style: TextStyle(fontSize: 12, color: Colors.white60))),
      ]);

  Widget _hrow(dynamic h) {
    final n = '${h['n']}';
    final inn = h['in'] == true;
    return ListTile(
        contentPadding: EdgeInsets.zero,
        leading: CircleAvatar(backgroundColor: const Color(0xFF2A1F63), child: Icon(inn ? Icons.south_west_rounded : _ico(h['k'] as String), size: 20, color: inn ? const Color(0xFF3DDC97) : kC)),
        onTap: inn ? null : () => _move(h),
        title: Text(n.isEmpty ? '${h['k']}' : n),
        subtitle: Text(inn ? 'Received' : '${h['k']}${h['cash'] == true ? ' · cash' : (h['auto'] == true ? ' · auto' : '')}', style: const TextStyle(fontSize: 12, color: Colors.white54)),
        trailing: Text('${inn ? '+' : '−'}${inr(h['a'] as num)}', style: TextStyle(color: inn ? const Color(0xFF3DDC97) : const Color(0xFFFF6B81), fontWeight: FontWeight.w700)));
  }

  Widget _nav(int i, IconData ic, String l) {
    final on = tab == i;
    return InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => i == 3 ? _reset() : setState(() => tab = i),
        child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(ic, color: on ? kC : Colors.white54),
              Text(l, style: TextStyle(fontSize: 11, fontWeight: on ? FontWeight.w700 : FontWeight.w400, color: on ? Colors.white : Colors.white54)),
            ])));
  }

  @override
  Widget build(BuildContext c) {
    if (d == null) return const Scaffold();
    final pages = [_home(), _manage(), _history()];
    return Scaffold(
      extendBody: true,
      body: Container(
          decoration: const BoxDecoration(gradient: RadialGradient(center: Alignment(-1, -1.1), radius: 1.2, colors: [Color(0x558B5CF6), Color(0x00000000)])),
          child: SafeArea(child: pages[tab])),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Container(
          width: 66,
          height: 66,
          decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [kP, kC]), boxShadow: [BoxShadow(color: Color(0x778B5CF6), blurRadius: 22)]),
          child: IconButton(icon: const Icon(Icons.qr_code_scanner_rounded, size: 30, color: Colors.white), onPressed: () => _pay(null, scan: true))),
      bottomNavigationBar: BottomAppBar(
          color: kCard,
          surfaceTintColor: Colors.transparent,
          shape: const CircularNotchedRectangle(),
          notchMargin: 8,
          height: 66,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _nav(0, Icons.home_rounded, 'Home'),
            _nav(1, Icons.tune_rounded, 'Manage'),
            const SizedBox(width: 48),
            _nav(2, Icons.history_rounded, 'History'),
            _nav(3, Icons.refresh_rounded, 'Reset'),
          ])),
    );
  }

  Widget _home() {
    final cats = Map<String, dynamic>.from(d!['c']);
    double tot = 0, spent = 0;
    cats.forEach((k, v) {
      tot += (v['t'] as num).toDouble();
      spent += (v['s'] as num).toDouble();
    });
    final hist = (d!['h'] as List).reversed.take(5).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 110), children: [
      _top(),
      const SizedBox(height: 16),
      ..._alerts(),
      ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: const Color(0x668B5CF6)),
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF2A1B5E), Color(0xFF14163A), Color(0xFF0B3446)])),
              child: Stack(children: [
                Positioned(
                    right: -50,
                    top: -50,
                    child: Container(
                        width: 190,
                        height: 190,
                        decoration: const BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [Color(0x5538D9F5), Color(0x0038D9F5)])))),
                Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('TOTAL BACHA HUA', style: TextStyle(fontSize: 11, letterSpacing: 2, color: Colors.white70)),
                      const SizedBox(height: 4),
                      Text(inr(tot - spent), style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800, letterSpacing: -1)),
                      const SizedBox(height: 10),
                      ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                              minHeight: 6,
                              value: tot > 0 ? ((tot - spent) / tot).clamp(0.0, 1.0).toDouble() : 0.0,
                              color: kC,
                              backgroundColor: Colors.white24)),
                      const SizedBox(height: 14),
                      Row(children: [
                        Expanded(child: _stat('Salary', inr(d!['sal'] as num))),
                        Expanded(child: _stat('Kharch', inr(spent))),
                      ]),
                      const SizedBox(height: 18),
                      ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF1A1340), shape: const StadiumBorder(), padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12)),
                          onPressed: () => _pay(null, scan: true),
                          icon: const Icon(Icons.qr_code_scanner_rounded, size: 20),
                          label: const Text('Scan & Pay', style: TextStyle(fontWeight: FontWeight.w700))),
                    ])),
              ]))),
      _h('Kahan kharch karna hai', 'Tap: pay  ·  Long press: edit / delete'),
      GridView.count(
          crossAxisCount: 4,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 0.78,
          children: [
            for (final e in cats.entries) _tile(e.key, e.value),
            InkWell(
                onTap: _cash,
                child: Column(children: [
                  Container(width: 62, height: 62, decoration: BoxDecoration(shape: BoxShape.circle, color: kCard, border: Border.all(color: kC, width: 1.5)), child: const Icon(Icons.payments_rounded, color: kC, size: 26)),
                  const SizedBox(height: 6),
                  const Text('Cash', style: TextStyle(fontSize: 12)),
                ])),
            InkWell(
                onTap: _add,
                child: Column(children: [
                  Container(width: 62, height: 62, decoration: BoxDecoration(shape: BoxShape.circle, color: kCard, border: Border.all(color: kP, width: 1.5)), child: const Icon(Icons.add_rounded, color: kP, size: 28)),
                  const SizedBox(height: 6),
                  const Text('Add', style: TextStyle(fontSize: 12)),
                ])),
          ]),
      _h('Recent kharch'),
      _card(Column(children: [
        if (hist.isEmpty) const Padding(padding: EdgeInsets.all(14), child: Text('Abhi koi kharch nahi', style: TextStyle(color: Colors.white54))),
        for (final h in hist) _hrow(h),
      ])),
    ]);
  }

  Widget _stat(String l, String v) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(l.toUpperCase(), style: const TextStyle(fontSize: 10, letterSpacing: 1.6, color: Colors.white60)),
        Text(v, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
      ]);

  Widget _tile(String k, dynamic v) {
    final t = (v['t'] as num).toDouble(), s = (v['s'] as num).toDouble(), l = t - s;
    final p = t > 0 ? (l / t).clamp(0.0, 1.0).toDouble() : 0.0;
    return InkWell(
        onTap: () => _pay(k),
        onLongPress: () => _edit(k),
        child: Column(children: [
          SizedBox(
              width: 66,
              height: 66,
              child: Stack(alignment: Alignment.center, children: [
                SizedBox(width: 66, height: 66, child: CircularProgressIndicator(value: p, strokeWidth: 3, color: kC, backgroundColor: const Color(0xFF242842))),
                Container(
                    width: 54,
                    height: 54,
                    decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF6D3FE0), Color(0xFF3A2A9E)])),
                    child: Icon(_ico(k), color: Colors.white, size: 26)),
              ])),
          const SizedBox(height: 6),
          Text(k, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
          Text(inr(l), style: TextStyle(fontSize: 11, color: l < 0 ? const Color(0xFFFF6B81) : Colors.white54)),
        ]));
  }

  Widget _manage() {
    final cats = Map<String, dynamic>.from(d!['c']);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 110), children: [
      _top(),
      _h('Categories manage karo', 'Amount badlo, delete karo ya naya add karo'),
      _card(
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const CircleAvatar(backgroundColor: Color(0xFF2A1F63), child: Icon(Icons.account_balance_wallet_rounded, color: kC, size: 20)),
              title: const Text('Monthly salary'),
              subtitle: Text(inr(d!['sal'] as num), style: const TextStyle(color: Colors.white60)),
              trailing: IconButton(icon: const Icon(Icons.edit_rounded, size: 20), onPressed: _editSal))),
      const SizedBox(height: 12),
      _card(Column(children: [
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Dusre apps ka payment auto minus'),
            subtitle: const Text('PhonePe, GPay, Paytm, bank SMS se', style: TextStyle(fontSize: 12, color: Colors.white54)),
            value: d!['auto'] != false,
            onChanged: (v) {
              d!['auto'] = v;
              _save();
            }),
        if (cats.isNotEmpty)
          ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Default category'),
              trailing: DropdownButton<String>(
                  value: cats.containsKey(d!['def']) ? d!['def'] as String : null,
                  hint: const Text('Chuno'),
                  items: [for (final k in cats.keys) DropdownMenuItem(value: k, child: Text(k))],
                  onChanged: (v) {
                    d!['def'] = v;
                    _save();
                  })),
      ])),
      const SizedBox(height: 12),
      _card(Column(children: [
        ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.inventory_2_outlined, color: kC),
            title: Text('Archive (${((d!['arch'] as List?) ?? []).length})'),
            subtitle: const Text('Hataye hue entries yahan rehte hain', style: TextStyle(fontSize: 12, color: Colors.white54)),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showArchive),
        ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.rule_rounded, color: kC),
            title: const Text('Detection log'),
            subtitle: const Text('Kaunse SMS / notification pakde gaye', style: TextStyle(fontSize: 12, color: Colors.white54)),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showLog),
        ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.sync_rounded, color: kC),
            title: const Text('PhonePe History sync'),
            subtitle: const Text('Jo SMS ke bina rah gaye, unhe add karo', style: TextStyle(fontSize: 12, color: Colors.white54)),
            trailing: const Icon(Icons.chevron_right),
            onTap: _reviewSync),
      ])),
      const SizedBox(height: 12),
      _card(Column(children: [
        for (final e in cats.entries)
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(backgroundColor: const Color(0xFF2A1F63), child: Icon(_ico(e.key), color: kC, size: 20)),
              title: Text(e.key),
              subtitle: Text('Amount ${inr(e.value['t'] as num)}  ·  Kharch ${inr(e.value['s'] as num)}', style: const TextStyle(fontSize: 12, color: Colors.white54)),
              trailing: IconButton(icon: const Icon(Icons.edit_rounded, size: 20), onPressed: () => _edit(e.key))),
        if (cats.isEmpty) const Padding(padding: EdgeInsets.all(14), child: Text('Koi category nahi', style: TextStyle(color: Colors.white54))),
      ])),
      const SizedBox(height: 16),
      Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: const LinearGradient(colors: [kP, kC])),
          child: TextButton.icon(
              style: TextButton.styleFrom(foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)),
              onPressed: _add,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Category add karo', style: TextStyle(fontWeight: FontWeight.w700)))),
    ]);
  }

  Widget _history() {
    final all = (d!['h'] as List).reversed.toList();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 110), children: [
      _top(),
      _h('Poori history'),
      _card(Column(children: [
        if (all.isEmpty) const Padding(padding: EdgeInsets.all(14), child: Text('Abhi koi kharch nahi', style: TextStyle(color: Colors.white54))),
        for (final h in all) _hrow(h),
      ])),
    ]);
  }
}
