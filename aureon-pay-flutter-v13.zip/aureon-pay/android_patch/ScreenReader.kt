package com.pavan.aureon_budget

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class ScreenReader : AccessibilityService() {
    private val money = Regex("(₹|rs\\.?|inr)\\s*[0-9]", RegexOption.IGNORE_CASE)
    private var lastKey = ""
    private var lastAt = 0L
    private var lastHist = ""
    private var lastHistAt = 0L

    override fun onAccessibilityEvent(ev: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        val lines = ArrayList<String>()
        collect(root, lines, 0)
        if (lines.isEmpty()) return
        val now = System.currentTimeMillis()

        // PhonePe History list: two or more "Paid to" / "Received from" rows
        if (pkg == "com.phonepe.app") {
            val markers = lines.count { it.equals("Paid to", true) || it.equals("Received from", true) }
            if (markers >= 2) {
                val txt = lines.joinToString("\n").take(3500)
                if (txt != lastHist && now - lastHistAt > 800) {
                    lastHist = txt
                    lastHistAt = now
                    push("acch", txt, now)
                }
                return
            }
        }

        // Payment success screen
        val txt = lines.joinToString(" ")
        if (!money.containsMatchIn(txt)) return
        if (!txt.contains("successful", ignoreCase = true)) return
        val key = txt.take(300)
        if (key == lastKey && now - lastAt < 60000) return
        lastKey = key
        lastAt = now
        push("acc", txt.take(600), now)
    }

    private fun push(kind: String, text: String, now: Long) {
        val sp = getSharedPreferences("aureon_txn", MODE_PRIVATE)
        val arr = JSONArray(sp.getString("q", "[]"))
        arr.put(JSONObject().put("pkg", kind).put("title", "").put("text", text).put("t", now))
        sp.edit().putString("q", arr.toString()).apply()
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 25) return
        val t = n.text ?: n.contentDescription
        if (t != null && t.isNotEmpty()) out.add(t.toString().trim())
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {}
}
