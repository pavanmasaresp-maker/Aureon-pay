package com.pavan.aureon_budget

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var pending: MethodChannel.Result? = null
    private var pendingScan: MethodChannel.Result? = null
    private var pendingImg: MethodChannel.Result? = null
    private var pendingLink: String? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "aureon/upi").setMethodCallHandler { call, result ->
            when (call.method) {
                "apps" -> {
                    val probe = Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay?pa=test@upi&pn=t&am=1&cu=INR"))
                    val list = packageManager.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY).filter { it.activityInfo.packageName != packageName }.map {
                        mapOf("pkg" to it.activityInfo.packageName, "name" to it.loadLabel(packageManager).toString())
                    }
                    result.success(list)
                }
                "pay" -> {
                    if (pending != null) {
                        result.error("busy", "Payment already running", null)
                    } else {
                        val i = Intent(Intent.ACTION_VIEW, Uri.parse(call.argument<String>("uri")))
                        i.setPackage(call.argument<String>("pkg"))
                        pending = result
                        try {
                            startActivityForResult(i, 9001)
                        } catch (e: Exception) {
                            pending = null
                            result.error("fail", e.message, null)
                        }
                    }
                }
                "drain" -> {
                    val sp = getSharedPreferences("aureon_txn", MODE_PRIVATE)
                    val q = sp.getString("q", "[]")
                    sp.edit().putString("q", "[]").apply()
                    result.success(q)
                }
                "enabled" -> {
                    val s = android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    result.success(s.contains(packageName))
                }
                "listenerSettings" -> {
                    startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                    result.success(null)
                }
                "appInfo" -> {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    result.success(null)
                }
                "scanImage" -> {
                    if (pendingImg != null) {
                        result.error("busy", "Picker already open", null)
                    } else {
                        pendingImg = result
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                        startActivityForResult(Intent.createChooser(i, "QR image chuno"), 9002)
                    }
                }
                "link" -> {
                    val l = pendingLink
                    pendingLink = null
                    result.success(l)
                }
                "accSettings" -> {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    result.success(null)
                }
                "smsGranted" -> {
                    result.success(checkSelfPermission(android.Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED)
                }
                "smsRequest" -> {
                    requestPermissions(arrayOf(android.Manifest.permission.RECEIVE_SMS), 77)
                    result.success(null)
                }
                "scan" -> {
                    if (pendingScan != null) {
                        result.error("busy", "Scanner already open", null)
                    } else {
                        pendingScan = result
                        com.google.zxing.integration.android.IntentIntegrator(this)
                            .setDesiredBarcodeFormats(com.google.zxing.integration.android.IntentIntegrator.QR_CODE)
                            .setPrompt("QR scan karo")
                            .setBeepEnabled(false)
                            .setOrientationLocked(false)
                            .addExtra("SCAN_TYPE", 2)
                            .initiateScan()
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun capture(i: Intent?) {
        val d = i?.dataString
        if (d != null && d.startsWith("upi://")) pendingLink = d
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        capture(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        capture(intent)
    }

    private fun decodeQr(uri: Uri): String {
        return try {
            var bmp = contentResolver.openInputStream(uri).use { android.graphics.BitmapFactory.decodeStream(it) } ?: return ""
            val maxSide = 1600
            val big = maxOf(bmp.width, bmp.height)
            if (big > maxSide) {
                val s = maxSide.toFloat() / big
                bmp = android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            }
            val w = bmp.width
            val h = bmp.height
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            val src = com.google.zxing.RGBLuminanceSource(w, h, px)
            val hints = mapOf<com.google.zxing.DecodeHintType, Any>(
                com.google.zxing.DecodeHintType.TRY_HARDER to true,
                com.google.zxing.DecodeHintType.POSSIBLE_FORMATS to listOf(com.google.zxing.BarcodeFormat.QR_CODE)
            )
            val reader = com.google.zxing.MultiFormatReader()
            for (s in listOf(src, src.invert())) {
                try {
                    return reader.decode(com.google.zxing.BinaryBitmap(com.google.zxing.common.HybridBinarizer(s)), hints).text
                } catch (e: Exception) {
                }
            }
            ""
        } catch (e: Exception) {
            ""
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9002) {
            val r = pendingImg
            pendingImg = null
            val uri = data?.data
            if (resultCode != RESULT_OK || uri == null) r?.success(null) else r?.success(decodeQr(uri))
        }
        if (requestCode == com.google.zxing.integration.android.IntentIntegrator.REQUEST_CODE) {
            val sr = com.google.zxing.integration.android.IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            val r = pendingScan
            pendingScan = null
            r?.success(sr?.contents)
        }
        if (requestCode == 9001) {
            val r = pending
            pending = null
            r?.success(data?.getStringExtra("response") ?: "")
        }
    }
}
