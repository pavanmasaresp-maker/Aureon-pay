package com.pavan.aureon_budget

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var pending: MethodChannel.Result? = null
    private var pendingScan: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "aureon/upi").setMethodCallHandler { call, result ->
            when (call.method) {
                "apps" -> {
                    val probe = Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay?pa=test@upi&pn=t&am=1&cu=INR"))
                    val list = packageManager.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY).map {
                        mapOf("pkg" to it.activityInfo.packageName, "name" to it.loadLabel(packageManager).toString())
                    }
                    result.success(list)
                }
                "pay" -> {
                    if (pending != null) {
                        result.error("busy", "Payment already running", null)
                    } else {
                        val i = Intent(Intent.ACTION_VIEW, Uri.parse(call.argument<String>("uri")))
                        i.setPackage(call.argument<String>("pkg"))
                        pending = result
                        try {
                            startActivityForResult(i, 9001)
                        } catch (e: Exception) {
                            pending = null
                            result.error("fail", e.message, null)
                        }
                    }
                }
                "drain" -> {
                    val sp = getSharedPreferences("aureon_txn", MODE_PRIVATE)
                    val q = sp.getString("q", "[]")
                    sp.edit().putString("q", "[]").apply()
                    result.success(q)
                }
                "enabled" -> {
                    val s = android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    result.success(s.contains(packageName))
                }
                "listenerSettings" -> {
                    startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                    result.success(null)
                }
                "appInfo" -> {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    result.success(null)
                }
                "smsGranted" -> {
                    result.success(checkSelfPermission(android.Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED)
                }
                "smsRequest" -> {
                    requestPermissions(arrayOf(android.Manifest.permission.RECEIVE_SMS), 77)
                    result.success(null)
                }
                "scan" -> {
                    if (pendingScan != null) {
                        result.error("busy", "Scanner already open", null)
                    } else {
                        pendingScan = result
                        com.google.zxing.integration.android.IntentIntegrator(this)
                            .setDesiredBarcodeFormats(com.google.zxing.integration.android.IntentIntegrator.QR_CODE)
                            .setPrompt("QR scan karo")
                            .setBeepEnabled(false)
                            .setOrientationLocked(false)
                            .initiateScan()
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == com.google.zxing.integration.android.IntentIntegrator.REQUEST_CODE) {
            val sr = com.google.zxing.integration.android.IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            val r = pendingScan
            pendingScan = null
            r?.success(sr?.contents)
        }
        if (requestCode == 9001) {
            val r = pending
            pending = null
            r?.success(data?.getStringExtra("response") ?: "")
        }
    }
}
