package com.pavan.aureon_budget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

class SmsReceiver : BroadcastReceiver() {
    private val money = Regex("(₹|rs\\.?|inr)\\s*[0-9]|(debited|credited)\\s+(by|with|for|of)?\\s*[0-9]", RegexOption.IGNORE_CASE)
    private val words = Regex("debited|credited|paid|received|sent|upi|transferred|withdrawn", RegexOption.IGNORE_CASE)

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val from = msgs[0].originatingAddress ?: ""
        if (!money.containsMatchIn(body) || !words.containsMatchIn(body)) return
        val sp = ctx.getSharedPreferences("aureon_txn", Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString("q", "[]"))
        arr.put(JSONObject().put("pkg", "sms").put("title", from).put("text", body).put("t", System.currentTimeMillis()))
        sp.edit().putString("q", arr.toString()).apply()
    }
}
