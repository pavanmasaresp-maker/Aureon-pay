1. GitHub pe naya repo banao (jaise Aureon-Pay).
2. Is zip ki saari files upload karo (.github folder, lib folder, pubspec.yaml).
3. Actions tab > Build APK chalne do (6-10 min).
4. Artifacts se AureonBudget-apk download karo, zip kholo, app-release.apk install karo.
