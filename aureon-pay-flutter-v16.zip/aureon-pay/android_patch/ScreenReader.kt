package com.pavan.aureon_budget

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class ScreenReader : AccessibilityService() {
    private val money = Regex("(₹|rs\\.?|inr)\\s*[0-9]", RegexOption.IGNORE_CASE)
    private val allowed = setOf("com.phonepe.app", "com.google.android.apps.nbu.paisa.user", "net.one97.paytm", "in.org.npci.upiapp")
    private var lastKey = ""
    private var lastAt = 0L
    private var lastHist = ""
    private var lastHistAt = 0L
    private var lastDbgAt = 0L

    private fun pickRoot(ev: AccessibilityEvent?): AccessibilityNodeInfo? {
        val a = rootInActiveWindow
        if (a != null && allowed.contains(a.packageName?.toString())) return a
        try {
            for (w in windows) {
                val r = w.root
                if (r != null && allowed.contains(r.packageName?.toString())) return r
            }
        } catch (e: Exception) {
        }
        return ev?.source ?: a
    }

    override fun onAccessibilityEvent(ev: AccessibilityEvent?) {
        val root = pickRoot(ev)
        val pkg = root?.packageName?.toString() ?: ev?.packageName?.toString() ?: ""
        val lines = ArrayList<String>()
        collect(root, lines, 0)
        val now = System.currentTimeMillis()

        // Diagnostic: what does Aureon actually see on PhonePe? (shown in Detection log)
        if (pkg == "com.phonepe.app" && now - lastDbgAt > 4000) {
            lastDbgAt = now
            push("dbg", "nodes=${lines.size} | " + lines.take(30).joinToString(" | "), now)
        }
        if (lines.isEmpty()) return

        // PhonePe History list: two or more "Paid to" / "Received from" rows
        if (pkg == "com.phonepe.app") {
            val markers = lines.count { it.equals("Paid to", true) || it.equals("Received from", true) }
            if (markers >= 2) {
                val txt = lines.joinToString("\n").take(3500)
                if (txt != lastHist && now - lastHistAt > 800) {
                    lastHist = txt
                    lastHistAt = now
                    push("acch", txt, now)
                }
                return
            }
        }

        // Payment success screen
        val txt = lines.joinToString(" ")
        if (!money.containsMatchIn(txt)) return
        if (!txt.contains("successful", ignoreCase = true)) return
        val key = txt.take(300)
        if (key == lastKey && now - lastAt < 60000) return
        lastKey = key
        lastAt = now
        push("acc", txt.take(600), now)
    }

    private fun push(kind: String, text: String, now: Long) {
        val sp = getSharedPreferences("aureon_txn", MODE_PRIVATE)
        val arr = JSONArray(sp.getString("q", "[]"))
        arr.put(JSONObject().put("pkg", kind).put("title", "").put("text", text).put("t", now))
        while (arr.length() > 300) arr.remove(0)
        sp.edit().putString("q", arr.toString()).apply()
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 30) return
        val t = n.text ?: n.contentDescription
        if (t != null && t.isNotEmpty()) out.add(t.toString().trim())
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {}
}
