import 'dart:math' as math;
import 'package:flutter/material.dart';

const _p = Color(0xFF8B5CF6), _c = Color(0xFF38D9F5);
const kPalette = [
  Color(0xFF8B5CF6),
  Color(0xFF38D9F5),
  Color(0xFFF472B6),
  Color(0xFFFBBF24),
  Color(0xFF34D399),
  Color(0xFF60A5FA),
  Color(0xFFFB7185),
  Color(0xFFA78BFA),
];

/// Number that counts up smoothly whenever the value changes.
class AnimatedMoney extends StatelessWidget {
  final double value;
  final TextStyle style;
  const AnimatedMoney(this.value, {super.key, required this.style});

  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: value),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
        builder: (ctx, v, _) => Text('₹${v.round()}', style: style),
      );
}

/// Interactive donut chart: tap a slice or a legend chip to highlight it.
class DonutChart extends StatefulWidget {
  final List<MapEntry<String, double>> data;
  const DonutChart({super.key, required this.data});

  @override
  State<DonutChart> createState() => _DonutState();
}

class _DonutState extends State<DonutChart> {
  int sel = -1;

  @override
  Widget build(BuildContext context) {
    final data = widget.data;
    final total = data.fold<double>(0, (a, e) => a + e.value);
    if (total <= 0) {
      return const SizedBox(height: 110, child: Center(child: Text('Is mahine abhi kharch nahi', style: TextStyle(color: Colors.white54))));
    }
    if (sel >= data.length) sel = -1;
    final centerTop = sel == -1 ? 'Total kharch' : data[sel].key;
    final centerVal = sel == -1 ? total : data[sel].value;
    return Column(children: [
      SizedBox(
        height: 200,
        child: LayoutBuilder(builder: (ctx, box) {
          return GestureDetector(
            onTapUp: (det) {
              final cx = box.maxWidth / 2, cy = box.maxHeight / 2;
              final dx = det.localPosition.dx - cx, dy = det.localPosition.dy - cy;
              final r = math.sqrt(dx * dx + dy * dy);
              final outer = math.min(box.maxWidth, box.maxHeight) / 2;
              if (r < outer * 0.45 || r > outer) {
                setState(() => sel = -1);
                return;
              }
              var ang = math.atan2(dy, dx) + math.pi / 2;
              if (ang < 0) ang += 2 * math.pi;
              var acc = 0.0;
              for (var i = 0; i < data.length; i++) {
                acc += data[i].value / total * 2 * math.pi;
                if (ang <= acc) {
                  setState(() => sel = sel == i ? -1 : i);
                  return;
                }
              }
            },
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: 1),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutCubic,
              builder: (ctx, prog, _) => Stack(alignment: Alignment.center, children: [
                CustomPaint(size: Size(box.maxWidth, box.maxHeight), painter: _DonutPainter(data.map((e) => e.value).toList(), total, sel, prog)),
                Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(centerTop, style: const TextStyle(fontSize: 12, color: Colors.white60)),
                  const SizedBox(height: 2),
                  Text('₹${centerVal.round()}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                ]),
              ]),
            ),
          );
        }),
      ),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (var i = 0; i < data.length; i++)
          GestureDetector(
            onTap: () => setState(() => sel = sel == i ? -1 : i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: sel == i ? kPalette[i % kPalette.length].withOpacity(0.25) : const Color(0xFF11131F),
                border: Border.all(color: kPalette[i % kPalette.length].withOpacity(sel == i ? 1 : 0.5)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: kPalette[i % kPalette.length])),
                const SizedBox(width: 6),
                Text(data[i].key, style: const TextStyle(fontSize: 12)),
              ]),
            ),
          ),
      ]),
    ]);
  }
}

class _DonutPainter extends CustomPainter {
  final List<double> vals;
  final double total;
  final int sel;
  final double prog;
  _DonutPainter(this.vals, this.total, this.sel, this.prog);

  @override
  void paint(Canvas cv, Size s) {
    final c = Offset(s.width / 2, s.height / 2);
    final r = math.min(s.width, s.height) / 2 - 18;
    var start = -math.pi / 2;
    for (var i = 0; i < vals.length; i++) {
      final sweep = vals[i] / total * 2 * math.pi * prog;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = i == sel ? 30 : 22
        ..color = kPalette[i % kPalette.length].withOpacity(sel == -1 || sel == i ? 1 : 0.3);
      cv.drawArc(Rect.fromCircle(center: c, radius: r), start, math.max(0.0, sweep - 0.03), false, paint);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(_DonutPainter o) => o.sel != sel || o.prog != prog || o.total != total;
}

/// Tappable bar chart (animated).
class MonthBars extends StatelessWidget {
  final List<String> labels;
  final List<double> values;
  final int selected;
  final ValueChanged<int> onTap;
  const MonthBars({super.key, required this.labels, required this.values, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    var mx = 0.0;
    for (final v in values) {
      if (v > mx) mx = v;
    }
    return SizedBox(
      height: 150,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (var i = 0; i < values.length; i++)
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onTap(i),
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Text(values[i] > 0 ? '₹${values[i].round()}' : '', style: TextStyle(fontSize: 10, color: i == selected ? Colors.white : Colors.white54)),
                const SizedBox(height: 4),
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: mx > 0 ? values[i] / mx : 0),
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.easeOutCubic,
                  builder: (ctx, f, _) => Container(
                    height: 90 * f + 4,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: i == selected ? const LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [_p, _c]) : null,
                      color: i == selected ? null : const Color(0xFF242842),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(labels[i], style: TextStyle(fontSize: 11, fontWeight: i == selected ? FontWeight.w700 : FontWeight.w400, color: i == selected ? Colors.white : Colors.white54)),
              ]),
            ),
          ),
      ]),
    );
  }
}

/// Shimmering placeholder block.
class Skeleton extends StatefulWidget {
  final double? w;
  final double h;
  final double r;
  const Skeleton({super.key, this.w, required this.h, this.r = 16});

  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _a = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..repeat();

  @override
  void dispose() {
    _a.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _a,
        builder: (ctx, _) => Container(
          width: widget.w,
          height: widget.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.r),
            gradient: LinearGradient(
              begin: Alignment(-1.5 + 3 * _a.value, 0),
              end: Alignment(-0.5 + 3 * _a.value, 0),
              colors: const [Color(0xFF0E1019), Color(0xFF1C2033), Color(0xFF0E1019)],
            ),
          ),
        ),
      );
}

/// Loading layout shown while data is being prepared.
class SkeletonHome extends StatelessWidget {
  const SkeletonHome({super.key});

  @override
  Widget build(BuildContext context) => ListView(physics: const NeverScrollableScrollPhysics(), children: [
        Row(children: const [Skeleton(w: 40, h: 40, r: 20), SizedBox(width: 10), Skeleton(w: 110, h: 18, r: 8)]),
        const SizedBox(height: 22),
        const Skeleton(h: 190, r: 28),
        const SizedBox(height: 14),
        const Skeleton(h: 64),
        const SizedBox(height: 22),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
          Skeleton(w: 64, h: 64, r: 32),
          Skeleton(w: 64, h: 64, r: 32),
          Skeleton(w: 64, h: 64, r: 32),
          Skeleton(w: 64, h: 64, r: 32),
        ]),
        const SizedBox(height: 22),
        const Skeleton(h: 62),
        const SizedBox(height: 10),
        const Skeleton(h: 62),
        const SizedBox(height: 10),
        const Skeleton(h: 62),
      ]);
}
