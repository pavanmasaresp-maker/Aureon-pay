package com.pavan.aureon_budget

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class TxnListener : NotificationListenerService() {
    private val apps = setOf(
        "com.phonepe.app", "com.google.android.apps.nbu.paisa.user", "net.one97.paytm",
        "in.org.npci.upiapp", "in.amazon.mShop.android.shopping", "com.dreamplug.androidapp",
        "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging",
        "com.oplus.mms", "com.coloros.mms", "com.truecaller",
        "com.msf.kbank.mobile", "com.kotak811mobilebankingapp.instantsavingsupiscanandpayrecharge",
        "com.sbi.lotusintouch", "com.sbi.upi", "com.snapwork.hdfc", "com.csam.icici.bank.imobile", "com.axis.mobile",
        "com.mobikwik_new", "com.freecharge.android"
    )
    private val money = Regex("(₹|rs\\.?|inr)\\s*[0-9]", RegexOption.IGNORE_CASE)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in apps) return
        val ex = sbn.notification.extras ?: return
        val title = ex.getCharSequence("android.title")?.toString() ?: ""
        val text = (ex.getCharSequence("android.bigText") ?: ex.getCharSequence("android.text"))?.toString() ?: ""
        if (!money.containsMatchIn("$title $text")) return
        val sp = getSharedPreferences("aureon_txn", MODE_PRIVATE)
        val arr = JSONArray(sp.getString("q", "[]"))
        arr.put(JSONObject().put("pkg", sbn.packageName).put("title", title).put("text", text).put("t", sbn.postTime))
        sp.edit().putString("q", arr.toString()).apply()
    }
}
