package com.pavan.aureon_budget

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class ScreenReader : AccessibilityService() {
    companion object {
        @Volatile
        var instance: ScreenReader? = null
    }

    private val money = Regex("(₹|rs\\.?|inr)\\s*[0-9]", RegexOption.IGNORE_CASE)
    private val allowed = setOf("com.phonepe.app", "com.google.android.apps.nbu.paisa.user", "net.one97.paytm", "in.org.npci.upiapp", "com.msf.kbank.mobile", "com.kotak811mobilebankingapp.instantsavingsupiscanandpayrecharge")
    private val markerRe = Regex("^(paid to|received from|sent to|money sent to|money received from|payment to|payment from|you paid|you received)\\b", RegexOption.IGNORE_CASE)
    private var targetPkg = "com.phonepe.app"
    private var lastKey = ""
    private var lastAt = 0L
    private var lastHist = ""
    private var lastHistAt = 0L
    private var lastDbgAt = 0L

    // one-tap auto sync state
    private val handler = Handler(Looper.getMainLooper())
    private var auto = false
    private var scrollsLeft = 0
    private var autoStart = 0L
    private var sameCount = 0
    private var lastSnap = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private fun pickRoot(ev: AccessibilityEvent?): AccessibilityNodeInfo? {
        val a = rootInActiveWindow
        if (a != null && allowed.contains(a.packageName?.toString())) return a
        try {
            for (w in windows) {
                val r = w.root
                if (r != null && allowed.contains(r.packageName?.toString())) return r
            }
        } catch (e: Exception) {
        }
        return ev?.source ?: a
    }

    private fun histMarkers(lines: List<String>): Int =
        lines.count { it.length < 70 && markerRe.containsMatchIn(it.trim()) }

    private fun captureHist(lines: List<String>, now: Long) {
        val txt = lines.joinToString("\n").take(3500)
        if (txt != lastHist) {
            lastHist = txt
            lastHistAt = now
            push("acch", txt, now)
        }
    }

    override fun onAccessibilityEvent(ev: AccessibilityEvent?) {
        val root = pickRoot(ev)
        val pkg = root?.packageName?.toString() ?: ev?.packageName?.toString() ?: ""
        val lines = ArrayList<String>()
        collect(root, lines, 0)
        val now = System.currentTimeMillis()

        if (allowed.contains(pkg) && now - lastDbgAt > 4000) {
            lastDbgAt = now
            push("dbg", "$pkg nodes=${lines.size} | " + lines.take(30).joinToString(" | "), now)
        }
        if (lines.isEmpty()) return

        if (allowed.contains(pkg) && histMarkers(lines) >= 2) {
            if (now - lastHistAt > 800) captureHist(lines, now)
            return
        }

        val txt = lines.joinToString(" ")
        if (!money.containsMatchIn(txt)) return
        if (!txt.contains("successful", ignoreCase = true)) return
        val key = txt.take(300)
        if (key == lastKey && now - lastAt < 60000) return
        lastKey = key
        lastAt = now
        push("acc", txt.take(600), now)
    }

    // ---- One-tap auto sync: open History tab and scroll. Only two actions are ever performed:
    // click on the "History" tab, and scroll the list forward. ----
    fun startAuto(maxScrolls: Int, pkgName: String) {
        targetPkg = pkgName
        auto = true
        scrollsLeft = maxScrolls
        autoStart = System.currentTimeMillis()
        sameCount = 0
        lastSnap = ""
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ step() }, 2500)
    }

    private fun finishAuto() {
        auto = false
        handler.removeCallbacksAndMessages(null)
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (e: Exception) {
        }
    }

    private fun step() {
        if (!auto) return
        if (System.currentTimeMillis() - autoStart > 120000 || scrollsLeft <= 0) {
            finishAuto()
            return
        }
        val root = pickRoot(null)
        if (root == null || root.packageName?.toString() != targetPkg) {
            handler.postDelayed({ step() }, 1000)
            return
        }
        val lines = ArrayList<String>()
        collect(root, lines, 0)
        if (histMarkers(lines) < 2) {
            val nav = findNav(root)
            if (nav != null) clickNode(nav)
            handler.postDelayed({ step() }, 1500)
            return
        }
        val now = System.currentTimeMillis()
        captureHist(lines, now)
        val snap = lines.joinToString("|")
        sameCount = if (snap == lastSnap) sameCount + 1 else 0
        lastSnap = snap
        if (sameCount >= 3) {
            finishAuto()
            return
        }
        val sc = findScrollable(root, 0)
        if (sc != null) {
            sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            scrollsLeft--
        }
        handler.postDelayed({ step() }, 900)
    }

    private fun findNav(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val names = listOf("history", "transaction history", "show transaction history", "balance & history", "passbook")
        var best: AccessibilityNodeInfo? = null
        var bestTop = -1
        for (word in listOf("History", "history", "Passbook")) {
            for (n in root.findAccessibilityNodeInfosByText(word)) {
                val tx = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase() ?: continue
                if (!names.contains(tx)) continue
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.top > bestTop) {
                    bestTop = r.top
                    best = n
                }
            }
        }
        return best
    }

    private fun clickNode(n: AccessibilityNodeInfo) {
        var c: AccessibilityNodeInfo? = n
        var i = 0
        while (c != null && i < 6) {
            if (c.isClickable) {
                c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
            c = c.parent
            i++
        }
    }

    private fun findScrollable(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 30) return null
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        if (n.isScrollable) {
            val r = Rect()
            n.getBoundsInScreen(r)
            best = n
            bestArea = r.width() * r.height()
        }
        for (i in 0 until n.childCount) {
            val c = findScrollable(n.getChild(i), depth + 1)
            if (c != null) {
                val r = Rect()
                c.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) {
                    best = c
                    bestArea = a
                }
            }
        }
        return best
    }

    private fun push(kind: String, text: String, now: Long) {
        val sp = getSharedPreferences("aureon_txn", MODE_PRIVATE)
        val arr = JSONArray(sp.getString("q", "[]"))
        arr.put(JSONObject().put("pkg", kind).put("title", "").put("text", text).put("t", now))
        while (arr.length() > 300) arr.remove(0)
        sp.edit().putString("q", arr.toString()).apply()
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 30) return
        val t = n.text ?: n.contentDescription
        if (t != null && t.isNotEmpty()) out.add(t.toString().trim())
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {}
}
